## Bonk

Turns linux kernel audit features into a death weapon.
You violate the bonk you must be bonked.

⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⡀⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠄⠄⢀⣔⢧⣓⢖⡮⣎⢮⢣⡫⡂⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠄⢠⡺⣧⣳⢵⡳⡝⡎⣎⢇⢏⢎⢲⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⡠⡄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⡀⡧⣫⡳⡳⡓⡝⢚⢻⢽⢺⢼⢼⢼⡁⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠠⣀⢀⠄⠄⣠⢪⢣⠊⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⠄⢀⢠⡪⣞⣝⣞⢮⡳⡱⢌⢂⠢⡑⡸⡸⡹⣝⡾⣄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⡱⡀⠈⠄⡀⡮⡪⠊⠄⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⠄⢠⢞⣜⢮⢮⢺⢜⢷⢽⢮⢇⢇⢕⢵⡧⣇⢇⢗⡿⡻⠄⠄⠄⠄⠄⠄⢠⠄⢄⠈⠂⠄⢀⢖⢝⠜⠄⠄⡀⠄⠄⠄⠄⠄⠄⠄⠄
⠄⠄⡠⢯⢯⡺⡧⣳⡱⢍⠇⡏⢎⠫⡢⢊⠜⢜⢕⠝⠁⠄⠄⠄⠄⠄⠄⣀⢄⠈⠢⠜⠄⢀⢔⢇⡯⣢⢆⡶⡤⣄⡀⡐⠄⠁⠄⠐⠄⠄
⠄⢠⣝⢵⡫⡿⣝⢮⡪⡣⡓⠜⢔⢑⠌⢔⠨⢂⠢⠡⠄⠄⠄⠄⠄⠄⠄⠙⢆⠅⠄⠄⡆⡧⣫⡺⡼⡪⢷⢽⢯⣗⢯⡆⡄⠄⠄⠄⠄⠄
⠄⣞⢾⢵⡫⡯⣗⣝⢮⢢⠪⡘⡐⢅⢊⠔⡨⠢⡑⡅⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢀⢮⣺⢽⢳⡹⡰⡨⠪⡽⣕⢯⡳⣝⡦⡀⠄⠄⡀⠄
⠄⣞⢽⣝⢮⢯⣺⢮⣳⡳⡵⡸⡨⡢⣑⢑⢌⢎⠪⡢⠄⠄⠄⠄⠄⠄⠄⠄⢠⠪⣳⣟⢮⢳⢕⣽⢪⢘⢜⢜⢮⡳⡽⣕⡯⣖⠄⠄⠄⠄
⠄⠘⣝⢮⢯⣳⣳⣻⣺⡪⣳⢱⢱⢸⢰⢵⡕⡔⡑⡌⡀⠄⠄⠄⠄⠄⢀⠦⠃⠁⢻⣽⢕⣗⡽⡳⡱⡐⢕⢕⡳⡽⣝⡮⣯⡺⣕⡀⠄⠄
⠄⠄⠈⠹⢳⣳⣻⣞⡧⣏⢮⢪⠪⡪⡪⡳⡽⣰⢨⢊⠪⠪⠢⡢⢄⢔⠍⠄⠄⠄⠈⠈⢑⢗⠝⢜⠰⡘⣜⢼⣝⣞⣗⢯⡳⣝⢮⢆⠄⠄
⠄⠄⠄⠄⠄⠈⠘⠷⢟⢮⡳⡱⣑⢌⠪⠨⠪⠺⠸⡨⡢⢄⣀⢰⠍⠄⠄⠄⠄⠄⠄⡀⢘⢌⢎⠪⡪⡪⡮⣗⢗⣗⢽⢕⢯⢮⡳⣯⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠙⡮⡣⡁⠄⠄⠄⠄⠄⠄⠈⠨⡢⡪⠢⠋⠄⠄⠄⠄⠄⠁⠄⠨⡢⡑⡅⢕⠕⣕⢳⢹⢸⢪⢳⡹⡮⡯⡷⡅⠄
⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢯⢎⢆⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠁⠄⠄⠄⠄⠈⠄⠄⠄⠈⠂⠑⠘⠐⠑⠘⠘⠘⠘⠘⠊⠙⠙⠙⠋⠃⠄

https://serverfault.com/questions/752455/what-is-the-correct-way-to-generate-etc-audit-audit-rules-on-centos7

This is a very portable binary. It installs its config file and its own rules

### Response time

FAST

### How to run

Download the binary from release
```bash
sudo ./bonk --mode=load --color=true    
sudo bonk --mode=bonk -v=false --color=false &
```

If you want more manual controls here they are
```
Usage of bonk:
  -backlog uint
        backlog limit (default 8192)
  -bonkip-a
        do not bonk processes in the allow list set by /etc/bonk/config.json (defualt false)
  -bonkip-d
        kills IP addresses in the deny list set by /etc/bonk/config.json (defualt false)
  -color
        whether to use color or not (default true)
  -config string
        where custom config is located
  -diag string
        (do not change) dump raw information from kernel to file (default "/var/log/bonk/logs")
  -info
        whether to show informational warnings or just bonks (default true)
  -mode string
        [load/bonk/list] choose between
        >'load' (load rules)
        >'bonk' (bonk processes)
        >'honk' (just honk no bonk)
         (default "load")
  -rate uint
        rate limit in kernel (default 0, no rate limit)
  -ro
        receive only using multicast, requires kernel 3.16+
  -v    whether to print to stdout or not (default true)
  -warn int
        Number of bonkable offenses before IP address is said to be a potential threat of an IP (default 10)                   
```

The default config is 
```
{
    "allowed-ips": [
        ""
    ],
    "banned-ips": [
        ""
    ],
    "allowed-user": [
        "kevin",
        "unset",
        "root"
    ],
    "rules": [
        "-w /var/www/html -p wa -key apache"
    ],
    "bonkable": [
        "actions",
        "passwd_modification",
        "group_modification",
        "user_modification",
        "network_modifications",
        "pam",
        "mail",
        "sshd",
        "rootkey",
        "systemd",
        "unauthedfileaccess",
        "priv_esc",
        "power",
        "dbus_send",
        "code_injection",
        "data_injection",
        "tracing",
        "register_injection",
        "software_mgmt"
    ]
}
```

### How it works


> load

yells at kernel to add rule, exits. Takes a while **but** launching a goroutine attack against the kernel seems like a bad idea....
I **could** then make the linux kernel immutable until reboot but that seems dumb and dangerous

> bonk

listens at the kernel yelling. Checks against the `config.json` file to see allowed users (if you remove root / current user / unset bonk will just kill itself).
If the syscall is naughty,

> honk

does not nuke just says hey I **would** nuke this if you want me to...

>bonkip-a / bonkip-b

looks at the process table to get the IP address and compares it against that of the config. If it violates it either tells you or **bonks** it.



### How to disable auditd
```bash
sudo service auditd stop    
```

### How to renable auditd
```bash
sudo systemctl enable auditd
sudo service auditd start
```

https://github.com/deep-security/auditd-config/blob/master/audit.rules
